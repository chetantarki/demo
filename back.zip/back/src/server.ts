import express from 'express';
import mongoose from 'mongoose';
import bodyParser from 'body-parser';
import userRoutes from './routes/user.routes';

import cors = require('cors');



const app = express();
const PORT = 3000;


app.use(cors());

app.use(bodyParser.json());
app.use('/users', userRoutes);

mongoose.connect('mongodb://localhost:27017/backend', {
  });



  app.use(cors({
    origin: 'http://localhost:4200', 
    methods: 'GET,PUT,POST,DELETE',
    credentials: true, 
  }));


app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});

