// typings/mongoose.d.ts

declare module 'mongoose' {
    interface ConnectOptions {
      useNewUrlParser?: boolean;
      useUnifiedTopology?: boolean;
      useCreateIndex?: boolean;
    }
  }
  