// import express, { Request, Response } from 'express';
// import UserModel from '../models/user.model';

// const router = express.Router();

// // Create a new task
// router.post('/', async (req: Request, res: Response) => {
//   try {
//     const { name, email, phone } = req.body;
//     const task = new UserModel({ name, email, phone });
//     await task.save();
//     res.status(201).json(task);
//   } catch (error) {
//     res.status(500).json({ error: 'Internal Server Error' });
//   }
// });

// // Get all tasks
// router.get('/', async (req: Request, res: Response) => {
//   try {
//     const tasks = await UserModel.find();
//     res.json(tasks);
//   } catch (error) {
//     res.status(500).json({ error: 'Internal Server Error' });
//   }
// });

// // Get a task by ID
// router.get('/:userId', async (req: Request, res: Response) => {
//   try {
//     const taskId = req.params.taskId;
//     const task = await UserModel.findById(taskId);

//     if (!task) {
//       return res.status(404).json({ error: 'Task not found' });
//     }

//     res.json(task);
//   } catch (error) {
//     res.status(500).json({ error: 'Internal Server Error' });
//   }
// });

// // Update a task by ID
// router.put('/:userId', async (req: Request, res: Response) => {
//   try {
//     const taskId = req.params.taskId;
//     const { name, email, phone } = req.body;

//     // Checking if the task exists
//     const existingTask = await UserModel.findById(taskId);
//     if (!existingTask) {
//       return res.status(404).json({ error: 'Task not found' });
//     }

//     // Updating task fields
//     existingTask.name = name || existingTask.name;
//     existingTask.email = email || existingTask.email;
//     existingTask.phone = phone || existingTask.phone;

//     // Saving updated task
//     const updatedTask = await existingTask.save();

//     res.json(updatedTask);
//   } catch (error) {
//     res.status(500).json({ error: 'Internal Server Error' });
//   }
// });

// // Delete a task by ID
// router.delete('/:userId', async (req: Request, res: Response) => {
//   try {
//     const taskId = req.params.taskId;
//     const deletedTask = await UserModel.findByIdAndDelete(taskId);

//     if (!deletedTask) {
//       return res.status(404).json({ error: 'Task not found' });
//     }

//     res.json(deletedTask);
//   } catch (error) {
//     res.status(500).json({ error: 'Internal Server Error' });
//   }
// });

// export default router;

































import express, { Request, Response } from 'express';
import UserModel from '../models/user.model';

const router = express.Router();

// Create a new task
router.post('/', async (req: Request, res: Response) => {
  try {
    const { name, email, phone } = req.body;
    const task = new UserModel({ name, email, phone });
    await task.save();
    res.status(201).json(task);
  } catch (error) {
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

// Get all tasks
router.get('/', async (req: Request, res: Response) => {
  try {
    const tasks = await UserModel.find();
    res.json(tasks);
  } catch (error) {
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

// Get a task by ID
router.get('/:userId', async (req: Request, res: Response) => {
  try {
    const taskId = req.params.taskId;
    const task = await UserModel.findById(taskId);

    if (!task) {
      return res.status(404).json({ error: 'Task not found' });
    }

    res.json(task);
  } catch (error) {
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

// Update a task by ID
router.put('/:userId', async (req: Request, res: Response) => {
  try {
    const taskId = req.params.taskId;
    const { name, email, phone } = req.body;

    // Checking if the task exists
    const existingTask = await UserModel.findById(taskId);
    if (!existingTask) {
      return res.status(404).json({ error: 'Task not found' });
    }

    // Updating task fields
    existingTask.name = name || existingTask.name;
    existingTask.email = email || existingTask.email;
    existingTask.phone = phone || existingTask.phone;

    // Saving updated task
    const updatedTask = await existingTask.save();

    res.json(updatedTask);
  } catch (error) {
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

// // Delete a task by ID
// router.delete('/:userId', async (req: Request, res: Response) => {
//   try {
//     const taskId = req.params.taskId;
//     const deletedTask = await UserModel.findByIdAndDelete(taskId);

//     if (!deletedTask) {
//       return res.status(404).json({ error: 'Task not found' });
//     }

//     res.json(deletedTask);
//   } catch (error) {
//     res.status(500).json({ error: 'Internal Server Error' });
//   }
// });










// Update a user by email
router.put('/:userEmail', async (req: Request, res: Response) => {
  try {
    const userEmail = req.params.userEmail;
    const { name, email, phone } = req.body;

    // Checking if the user exists
    const existingUser = await UserModel.findOne({ email: userEmail });
    if (!existingUser) {
      return res.status(404).json({ error: 'User not found' });
    }

    // Updating user fields
    existingUser.name = name || existingUser.name;
    existingUser.email = email || existingUser.email;
    existingUser.phone = phone || existingUser.phone;

    // Saving updated user
    const updatedUser = await existingUser.save();

    res.json(updatedUser);
  } catch (error) {
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

// Delete a user by email
router.delete('/:userEmail', async (req: Request, res: Response) => {
  try {
    const userEmail = req.params.userEmail;
    const deletedUser = await UserModel.findOneAndDelete({ email: userEmail });

    if (!deletedUser) {
      return res.status(404).json({ error: 'User not found' });
    }

    res.json(deletedUser);
  } catch (error) {
    res.status(500).json({ error: 'Internal Server Error' });
  }
});











export default router;
